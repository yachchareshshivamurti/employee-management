

## Istallation Guide:
1. Clone the whole repository to your localhost folder.
2. Launch XAMPP (or any other similar service) and start Apache, My SQL
3. Goto phpmyadmin and create a database named **370project** and then import the file named **370project.sql**
4. Then launch the site.

## Login Info:
### Admin Panel:
ID: admin

Pass: admin

### User Panel:
ID: yachchareshshivamurthi@gmail.com

Pass: 1234 